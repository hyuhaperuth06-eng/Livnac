LIVNAC — Ideas in. Real progress out.

This package contains the LIVNAC static website prototype as index.html.

To publish using GitHub and Cloudflare Pages:
1. Create a GitHub repository named livnac.
2. Upload index.html to the repository's top level (not inside a subfolder).
3. In Cloudflare, open Workers & Pages and create a Pages project connected to the GitHub repository.
4. For a static HTML site, use no build command and set the output directory to / (or the repository root, depending on the interface).
5. Deploy and test the pages.dev link.

This prototype is not connected to a live AI model and does not include user accounts or cloud project storage. Do not put API keys or passwords in index.html.
